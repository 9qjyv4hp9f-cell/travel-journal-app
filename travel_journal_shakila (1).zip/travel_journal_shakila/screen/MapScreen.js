import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Platform,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
} from "react-native";
import * as Location from "expo-location";

let MapView, Marker;
if (Platform.OS !== "web") {
  const Maps = require("react-native-maps");
  MapView = Maps.default;
  Marker = Maps.Marker;
}

export default function MapScreen({ navigation, route }) {
  const [baseLocation, setBaseLocation] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [loading, setLoading] = useState(true);

  const tripId = route?.params?.tripId;
  const existingLocation = route?.params?.location || null;
  const onLocationPicked = route?.params?.onLocationPicked;

  useEffect(() => {
    (async () => {
      if (Platform.OS === "web") {
        setLoading(false);
        return;
      }

      try {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== "granted") {
          Alert.alert("Permission denied", "Cannot access location.");
          setLoading(false);
          return;
        }

        let current = await Location.getCurrentPositionAsync({});
        const currentCoords = current?.coords || null;

        const initial =
          existingLocation ||
          currentCoords || {
            latitude: 37.5665,
            longitude: 126.9780,
          };

        setBaseLocation(initial);
        setSelectedLocation(initial);
        setLoading(false);
      } catch (e) {
        console.log("Location error:", e);
        setLoading(false);
      }
    })();
  }, []);

  if (Platform.OS === "web") {
    return (
      <View style={styles.center}>
        <Text style={{ textAlign: "center", paddingHorizontal: 16 }}>
          🗺️ Map is not supported on Snack Web.{"\n"}
          Please open in Expo Go app 📱
        </Text>
      </View>
    );
  }

  if (!MapView) {
    return (
      <View style={styles.center}>
        <Text>Map component unavailable.</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  const region = selectedLocation || baseLocation;

  /** SAVE LOCATION BUTTON */
  const handleSaveLocation = () => {
    if (!selectedLocation) {
      Alert.alert("No location selected", "Tap on the map to choose one.");
      return;
    }

    if (typeof onLocationPicked === "function") {
      onLocationPicked({
        latitude: selectedLocation.latitude,
        longitude: selectedLocation.longitude,
      });
    }

    navigation.goBack();
  };

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={styles.map}
        region={{
          latitude: region.latitude,
          longitude: region.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
        onPress={(e) => {
          setSelectedLocation(e.nativeEvent.coordinate);
        }}
      >
        {selectedLocation && <Marker coordinate={selectedLocation} />}
      </MapView>

      {/* SAVE BUTTON */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.saveButton} onPress={handleSaveLocation}>
          <Text style={styles.saveButtonText}>Save Location</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  map: { flex: 1 },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  bottomBar: {
    position: "absolute",
    bottom: 20,
    left: 0,
    right: 0,
    alignItems: "center",
  },
  saveButton: {
    backgroundColor: "#ff69b4",
    paddingHorizontal: 26,
    paddingVertical: 14,
    borderRadius: 30,
    elevation: 4,
  },
  saveButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },
});

import React from "react";
import { View, Text, Image, StyleSheet, ScrollView } from "react-native";

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      {/* Top title */}
      <Text style={styles.title}>HOME</Text>

      {/* 1 — Ocean */}
      <View style={styles.card}>
        <Image
          source={require("../assets/ocean.jpg")}
          style={styles.image}
        />
        <View style={styles.infoRow}>
          <Text style={styles.place}>Ocean</Text>
          <Text style={styles.date}>2024</Text>
        </View>
      </View>

      {/* 2 — Sunset */}
      <View style={styles.card}>
        <Image
          source={require("../assets/sunset.jpg")}
          style={styles.image}
        />
        <View style={styles.infoRow}>
          <Text style={styles.place}>Sunset</Text>
          <Text style={styles.date}>2024</Text>
        </View>
      </View>

      {/* 3 — German */}
      <View style={styles.card}>
        <Image
          source={require("../assets/german.jpg")}
          style={styles.image}
        />
        <View style={styles.infoRow}>
          <Text style={styles.place}>Germany</Text>
          <Text style={styles.date}>2024</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffff",
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#111827",
  },
  card: {
    borderRadius: 18,
    overflow: "hidden",
    backgroundColor: "#f3f4f6",
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
  image: {
    width: "100%",
    height: 200,
  },
  infoRow: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  place: {
    fontSize: 18,
    fontWeight: "600",
    color: "#111827",
  },
  date: {
    fontSize: 13,
    color: "#6b7280",
    marginTop: 4,
  },
});
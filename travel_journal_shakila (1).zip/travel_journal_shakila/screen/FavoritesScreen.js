import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const SCREEN_WIDTH = Dimensions.get("window").width;

export default function FavoritesScreen({ navigation }) {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const loadFavorites = async () => {
      try {
        const saved = await AsyncStorage.getItem("TRIPS_DATA");
        if (!saved) return;

        const trips = JSON.parse(saved);

        const favs = trips.filter((t) => t.favorite === true);

        setFavorites(favs);
      } catch (e) {
        console.log("Load favorites error:", e);
      }
    };

    // Load favorites each time screen focuses
    const unsubscribe = navigation.addListener("focus", loadFavorites);

    return unsubscribe;
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>⭐ Favorite Trips</Text>

      {favorites.length === 0 ? (
        <Text style={styles.noFavText}>You have no favorites yet.</Text>
      ) : (
        <ScrollView
          style={{ marginTop: 10 }}
          contentContainerStyle={{ paddingBottom: 40 }}
        >
          {favorites.map((trip) => (
            <View key={trip.id} style={styles.card}>
              <Image
                source={{ uri: trip.images?.[0] }}
                style={styles.image}
              />

              <View style={styles.cardContent}>
                <Text style={styles.tripName}>{trip.name}</Text>
                <Text style={styles.description}>
                  {trip.description || "No description"}
                </Text>

                {trip.location && (
                  <Text style={styles.locationText}>
                    📍 Location saved
                  </Text>
                )}

                {trip.tripDate && (
                  <Text style={styles.dateText}>🗓 {trip.tripDate}</Text>
                )}

                {/* mood chip */}
                <View style={styles.moodChip}>
                  <Text style={styles.moodEmoji}>
                    {trip.mood === "happy"
                      ? "😍"
                      : trip.mood === "okay"
                      ? "😶"
                      : "😫"}
                  </Text>
                  <Text style={styles.moodLabel}>
                    {trip.mood === "happy"
                      ? "Happy"
                      : trip.mood === "okay"
                      ? "Okay"
                      : "Tired"}
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F5",
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: "800",
    color: "#111827",
    marginBottom: 10,
  },
  noFavText: {
    marginTop: 40,
    textAlign: "center",
    fontSize: 16,
    color: "#6B7280",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 20,
    marginBottom: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 3,
  },
  image: {
    width: "100%",
    height: 160,
  },
  cardContent: {
    padding: 14,
  },
  tripName: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },
  description: {
    color: "#4B5563",
    marginTop: 4,
  },
  locationText: {
    marginTop: 6,
    color: "#0EA5E9",
    fontWeight: "600",
  },
  dateText: {
    marginTop: 4,
    color: "#6B7280",
  },
  moodChip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#EEF2FF",
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    marginTop: 8,
  },
  moodEmoji: {
    fontSize: 18,
  },
  moodLabel: {
    marginLeft: 6,
    fontSize: 12,
    color: "#4B5563",
    fontWeight: "600",
  },
});

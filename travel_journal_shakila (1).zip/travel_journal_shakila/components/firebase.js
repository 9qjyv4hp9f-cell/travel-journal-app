import firebase from "firebase"

const firebaseConfig = {
  apiKey: "AIzaSyCq-8qtvCBaelOH-bE_i13pkGY9TPKykZQ",
  authDomain: "real-time-test-eb7e5.firebaseapp.com",
  databaseURL: "https://real-time-test-eb7e5-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "real-time-test-eb7e5",
  storageBucket: "real-time-test-eb7e5.appspot.com",
  messagingSenderId: "726301221137",
  appId: "1:726301221137:web:d4982c8f5208ec48d3ecb0"
};

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

export default firebase;
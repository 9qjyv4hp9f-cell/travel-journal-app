import React, { useState, useRef, useEffect, useContext } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  TextInput,
  StyleSheet,
  ScrollView,
  Dimensions,
  Alert,
  Platform,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ThemeContext } from "../ThemeContext";

const CATEGORY_OPTIONS = [
  "All",
  "City",
  "Beach",
  "Nature",
  "Shopping",
  "Cafe",
  "Abroad",
];

const MOOD_OPTIONS = [
  { key: "happy", emoji: "😍", label: "Happy" },
  { key: "okay", emoji: "😶", label: "Okay" },
  { key: "tired", emoji: "😫", label: "Tired" },
];

const SCREEN_WIDTH = Dimensions.get("window").width;

let CardMapView, CardMarker;
if (Platform.OS !== "web") {
  const Maps = require("react-native-maps");
  CardMapView = Maps.default;
  CardMarker = Maps.Marker;
}

export default function AddTripScreen({ navigation }) {
  const { theme } = useContext(ThemeContext);
  const isDark = theme === "dark";

  const [trips, setTrips] = useState([]);
  const [editingTripId, setEditingTripId] = useState(null);
  const [editingDescriptionId, setEditingDescriptionId] = useState(null);
  const [editedName, setEditedName] = useState("");
  const [editedDescription, setEditedDescription] = useState("");
  const scrollViewRef = useRef();

  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const [viewerVisible, setViewerVisible] = useState(false);
  const [currentTripImages, setCurrentTripImages] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [datePickerTripId, setDatePickerTripId] = useState(null);
  const [tempDateInput, setTempDateInput] = useState("");

  useEffect(() => {
    loadTrips();
  }, []);

  useEffect(() => {
    saveTrips(trips);
  }, [trips]);

  const saveTrips = async (data) => {
    try {
      await AsyncStorage.setItem("TRIPS_DATA", JSON.stringify(data));
    } catch (e) {
      console.log("Save error:", e);
    }
  };

  const loadTrips = async () => {
    try {
      const saved = await AsyncStorage.getItem("TRIPS_DATA");
      if (saved) {
        const parsed = JSON.parse(saved);
        const normalized = parsed.map((t) => ({
          ...t,
          images: Array.isArray(t.images)
            ? t.images
            : t.image
            ? [t.image]
            : [],
          location: t.location || null,
          tripDate: t.tripDate || null,
          mood: t.mood || "happy",
        }));

        setTrips(normalized);
        return;
      }

      const img =
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80";

      setTrips([
        {
          id: "1",
          name: "Seoul Trip",
          description: "Beautiful trip to Seoul",
          image: img,
          images: [img],
          favorite: true,
          savedImage: true,
          category: "City",
          tripDate: null,
          location: null,
          mood: "happy",
        },
      ]);
    } catch (e) {
      console.log("Load error:", e);
    }
  };

  const addTrip = () => {
    const newTrip = {
      id: Date.now().toString(),
      name: "New Trip",
      description: "No description",
      image: null,
      images: [],
      favorite: false,
      savedImage: false,
      category: selectedCategory === "All" ? "City" : selectedCategory,
      tripDate: null,
      location: null,
      mood: "happy",
    };

    setTrips((prev) => [...prev, newTrip]);

    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 120);
  };

  const pickImage = async (tripId) => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 1,
    });

    if (result.canceled) return;

    const newUris = result.assets.map((a) => a.uri);

    setTrips((prev) =>
      prev.map((t) =>
        t.id === tripId
          ? {
              ...t,
              images: [...(t.images || []), ...newUris],
              image: [...(t.images || []), ...newUris][0] || null,
            }
          : t
      )
    );
  };

  const saveImage = (id) => {
    setTrips((prev) =>
      prev.map((t) => (t.id === id ? { ...t, savedImage: true } : t))
    );
  };

  const deleteTrip = (id) => {
    setTrips((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleFavorite = (id) => {
    setTrips((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, favorite: !t.favorite } : t
      )
    );
  };

  const saveName = (id) => {
    if (editedName.trim()) {
      setTrips((prev) =>
        prev.map((t) => (t.id === id ? { ...t, name: editedName } : t))
      );
    }
    setEditingTripId(null);
    setEditedName("");
  };

  const saveDescription = (id) => {
    setTrips((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, description: editedDescription || "No description" }
          : t
      )
    );
    setEditingDescriptionId(null);
    setEditedDescription("");
  };

  const openLocationPicker = (trip) =>
    navigation.navigate("Map", {
      tripId: trip.id,
      location: trip.location || null,
      onLocationPicked: (coords) => {
        setTrips((prev) =>
          prev.map((t) =>
            t.id === trip.id ? { ...t, location: coords } : t
          )
        );
      },
    });

  const openImageViewer = (images, index) => {
    setCurrentTripImages(images);
    setCurrentIndex(index);
    setViewerVisible(true);
  };

  // ---------- CARD RENDER ----------
  const renderTripCard = (trip) => (
    <View key={trip.id} style={styles.card}>
      <View style={styles.cardHeader}>
        {editingTripId === trip.id ? (
          <View style={styles.editRow}>
            <TextInput
              value={editedName}
              onChangeText={setEditedName}
              style={styles.editInput}
              placeholder="Enter trip name"
              placeholderTextColor="#9CA3AF"
              autoFocus
            />
            <TouchableOpacity
              style={styles.saveButton}
              onPress={() => saveName(trip.id)}
            >
              <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <Text style={styles.tripName}>{trip.name}</Text>
        )}

        <TouchableOpacity onPress={() => toggleFavorite(trip.id)}>
          <Text style={[styles.star, trip.favorite && styles.favoriteStar]}>
            ★
          </Text>
        </TouchableOpacity>
      </View>

      {/* DATE */}
      <View style={styles.tripDateRow}>
        <Text style={styles.tripDateText}>
          {trip.tripDate ? `🗓️ ${trip.tripDate}` : "🗓️ No date set"}
        </Text>

        <TouchableOpacity
          style={styles.dateSetButton}
          onPress={() => {
            setDatePickerVisible(true);
            setDatePickerTripId(trip.id);
            setTempDateInput(trip.tripDate || "");
          }}
        >
          <Text style={styles.dateSetButtonText}>
            {trip.tripDate ? "Change Date" : "Set Date"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* LOCATION */}
      <View style={styles.locationRow}>
        <Text style={styles.locationText}>
          {trip.location ? "📍 Location added" : "📍 No location set"}
        </Text>

        <TouchableOpacity
          style={styles.locationButton}
          onPress={() => openLocationPicker(trip)}
        >
          <Text style={styles.locationButtonText}>
            {trip.location ? "Change Location" : "Set Location"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* MINI MAP */}
      {trip.location && Platform.OS !== "web" && CardMapView ? (
        <TouchableOpacity onPress={() => openLocationPicker(trip)}>
          <View style={styles.miniMapContainer}>
            <CardMapView
              style={styles.miniMap}
              pointerEvents="none"
              region={{
                latitude: trip.location.latitude,
                longitude: trip.location.longitude,
                latitudeDelta: 0.02,
                longitudeDelta: 0.02,
              }}
            >
              <CardMarker coordinate={trip.location} />
            </CardMapView>
          </View>
        </TouchableOpacity>
      ) : null}

      {/* IMAGES */}
      {trip.images?.length > 0 ? (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.imageScroll}
        >
          {trip.images.map((uri, index) => (
            <TouchableOpacity
              key={index}
              onPress={() => openImageViewer(trip.images, index)}
            >
              <Image source={{ uri }} style={styles.multiImage} />
            </TouchableOpacity>
          ))}
        </ScrollView>
      ) : (
        <View style={styles.placeholderImage}>
          <Text style={styles.placeholderText}>No image</Text>
        </View>
      )}

      <TouchableOpacity
        style={styles.imageButton}
        onPress={() => pickImage(trip.id)}
      >
        <Text style={styles.imageButtonText}>Choose Image</Text>
      </TouchableOpacity>

      {trip.images?.length > 0 && (
        <TouchableOpacity
          style={styles.saveImageButton}
          onPress={() => saveImage(trip.id)}
        >
          <Text style={styles.saveImageButtonText}>
            {trip.savedImage ? "Saved Image" : "Save Image"}
          </Text>
        </TouchableOpacity>
      )}

      {/* DESCRIPTION */}
      {editingDescriptionId === trip.id ? (
        <View style={styles.descriptionEditContainer}>
          <TextInput
            style={styles.descriptionInput}
            value={editedDescription}
            onChangeText={setEditedDescription}
            placeholder="Write your memory..."
            placeholderTextColor="#9CA3AF"
            multiline
            autoFocus
          />
          <TouchableOpacity
            style={styles.saveButton}
            onPress={() => saveDescription(trip.id)}
          >
            <Text style={styles.saveButtonText}>Save</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <TouchableOpacity
          onPress={() => {
            setEditingDescriptionId(trip.id);
            setEditedDescription(
              trip.description === "No description" ? "" : trip.description
            );
          }}
          style={styles.descriptionContainer}
        >
          <Text
            style={[
              styles.descriptionText,
              trip.description === "No description" &&
                styles.placeholderDescription,
            ]}
          >
            {trip.description}
          </Text>
        </TouchableOpacity>
      )}

      {/* MOOD LABEL */}
      <Text style={styles.moodLabelSmall}>How did you feel today?</Text>

      {/* MOOD OPTIONS */}
      <View style={styles.moodOptionsRow}>
        {MOOD_OPTIONS.map((m) => (
          <TouchableOpacity
            key={m.key}
            style={[
              styles.moodButtonSmall,
              trip.mood === m.key && styles.moodButtonSelected,
            ]}
            onPress={() =>
              setTrips((prev) =>
                prev.map((t) =>
                  t.id === trip.id ? { ...t, mood: m.key } : t
                )
              )
            }
          >
            <Text style={styles.moodEmoji}>{m.emoji}</Text>
            <Text
              style={[
                styles.moodTextSmall,
                trip.mood === m.key && styles.moodTextSelected,
              ]}
            >
              {m.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* MOOD CHIP */}
      <View style={styles.cardMoodChip}>
        <Text style={styles.cardMoodEmoji}>
          {MOOD_OPTIONS.find((m) => m.key === trip.mood)?.emoji}
        </Text>
        <Text style={styles.cardMoodChipText}>
          {MOOD_OPTIONS.find((m) => m.key === trip.mood)?.label}
        </Text>
      </View>

      {/* ACTION BUTTONS */}
      <View style={styles.actionButtons}>
        <TouchableOpacity
          style={[styles.actionButton, styles.editButton]}
          onPress={() => {
            setEditingTripId(trip.id);
            setEditedName(trip.name);
          }}
        >
          <Text style={styles.editButtonText}>Edit Name</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => deleteTrip(trip.id)}
        >
          <Text style={styles.deleteButtonText}>Delete Trip</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const favoritesFiltered = showFavoritesOnly
    ? trips.filter((t) => t.favorite)
    : trips;

  const searchFiltered = searchQuery.trim()
    ? favoritesFiltered.filter(
        (t) =>
          t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : favoritesFiltered;

  const visibleTrips =
    selectedCategory === "All"
      ? searchFiltered
      : searchFiltered.filter((t) => t.category === selectedCategory);

  const noResults =
    searchQuery.trim().length > 0 && visibleTrips.length === 0;

  return (
    <View style={styles.container}>
      <ScrollView
        ref={scrollViewRef}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingBottom: 40,
          flexGrow: 1,
        }}
      >
        {/* HEADER */}
        <View style={styles.header}>
          <Text style={styles.title}>Add Trips</Text>
        </View>

        {/* FAVORITES FILTER */}
        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              showFavoritesOnly && styles.filterButtonActive,
            ]}
            onPress={() => navigation.navigate("Favorites")}
          >
            <Text
              style={[
                styles.filterButtonText,
                showFavoritesOnly && styles.filterButtonTextActive,
              ]}
            >
              {showFavoritesOnly ? "Show All Trips" : "Show Favorites Only"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* CATEGORY CHIPS */}
        <View style={styles.categoryFilterRow}>
          {CATEGORY_OPTIONS.map((cat) => (
            <TouchableOpacity
              key={cat}
              style={[
                styles.categoryChip,
                selectedCategory === cat && styles.categoryChipActive,
              ]}
              onPress={() => setSelectedCategory(cat)}
            >
              <Text
                style={[
                  styles.categoryChipText,
                  selectedCategory === cat && styles.categoryChipTextActive,
                ]}
              >
                {cat}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* SEARCH */}
        <View style={styles.searchWrapper}>
          <Ionicons
            name="search"
            size={18}
            color="#9CA3AF"
            style={{ marginRight: 6 }}
          />
          <TextInput
            style={styles.searchInput}
            placeholder="Search trips..."
            placeholderTextColor="#9CA3AF"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* ADD TRIP */}
        <TouchableOpacity style={styles.addButton} onPress={addTrip}>
          <Text style={styles.addText}>+ Add New Trip</Text>
        </TouchableOpacity>

        {noResults ? (
          <Text style={styles.noResultsText}>No trip found</Text>
        ) : (
          visibleTrips.map(renderTripCard)
        )}

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* IMAGE VIEWER */}
      {viewerVisible && (
        <View style={styles.viewerOverlay}>
          <TouchableOpacity
            onPress={() => setViewerVisible(false)}
            style={styles.viewerCloseButton}
            activeOpacity={0.8}
          >
            <Ionicons name="close" size={36} color="#fff" />
          </TouchableOpacity>

          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            contentOffset={{
              x: currentIndex * SCREEN_WIDTH,
              y: 0,
            }}
            style={styles.viewerScroll}
          >
            {currentTripImages.map((img, idx) => (
              <View key={idx} style={styles.viewerPage}>
                <Image source={{ uri: img }} style={styles.viewerImage} />
              </View>
            ))}
          </ScrollView>
        </View>
      )}

      {/* DATE PICKER */}
      {datePickerVisible && (
        <View style={styles.dateOverlay}>
          <View style={styles.dateBox}>
            <Text style={styles.dateTitle}>Set Trip Date (YYYY-MM-DD)</Text>

            <TextInput
              style={styles.dateInput}
              placeholder="2024-11-29"
              placeholderTextColor="#9CA3AF"
              value={tempDateInput}
              onChangeText={setTempDateInput}
            />

            <View style={styles.dateButtonsRow}>
              <TouchableOpacity
                style={[styles.dateButton, styles.dateCancelButton]}
                onPress={() => setDatePickerVisible(false)}
              >
                <Text style={styles.dateCancelText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.dateButton, styles.dateSaveButton]}
                onPress={() => {
                  const val = tempDateInput.trim();
                  if (!val.match(/^\d{4}-\d{2}-\d{2}$/)) {
                    Alert.alert("Invalid format", "Use YYYY-MM-DD");
                    return;
                  }

                  setTrips((prev) =>
                    prev.map((t) =>
                      t.id === datePickerTripId ? { ...t, tripDate: val } : t
                    )
                  );

                  setDatePickerVisible(false);
                }}
              >
                <Text style={styles.dateSaveText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F4F5",
  },

  header: {
    marginTop: 16,
    marginBottom: 6,
  },
  title: {
    fontSize: 28,
    fontWeight: "800",
    color: "#111827",
  },

  filterRow: {
    marginTop: 8,
    alignItems: "flex-start",
  },
  filterButton: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#D1D5DB",
    backgroundColor: "#FFFFFF",
  },
  filterButtonActive: {
    backgroundColor: "#0EA5E9",
    borderColor: "#0EA5E9",
  },
  filterButtonText: {
    color: "#374151",
    fontWeight: "500",
  },
  filterButtonTextActive: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  categoryFilterRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 10,
  },
  categoryChip: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "#FFFFFF",
    marginRight: 8,
    marginBottom: 8,
  },
  categoryChipActive: {
    backgroundColor: "#0EA5E9",
    borderColor: "#0EA5E9",
  },
  categoryChipText: {
    fontSize: 12,
    color: "#4B5563",
  },
  categoryChipTextActive: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  searchWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F3F4F6",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    marginTop: 8,
    marginBottom: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: "#111827",
  },

  addButton: {
    backgroundColor: "#0EA5E9",
    paddingVertical: 10,
    borderRadius: 999,
    alignItems: "center",
    marginVertical: 10,
  },
  addText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
  noResultsText: {
    textAlign: "center",
    color: "#6B7280",
    fontSize: 14,
    marginTop: 20,
    fontStyle: "italic",
  },

  card: {
    backgroundColor: "#FFFFFF",
    padding: 14,
    borderRadius: 24,
    marginBottom: 14,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  tripName: {
    fontSize: 18,
    fontWeight: "600",
    color: "#111827",
  },
  star: {
    fontSize: 22,
    color: "#D1D5DB",
  },
  favoriteStar: {
    color: "#FBBF24",
  },

  tripDateRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 6,
    marginBottom: 4,
  },
  tripDateText: {
    fontSize: 12,
    color: "#6B7280",
  },
  dateSetButton: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "#FFFFFF",
  },
  dateSetButtonText: {
    fontSize: 11,
    color: "#0EA5E9",
    fontWeight: "600",
  },

  locationRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  locationText: {
    fontSize: 12,
    color: "#6B7280",
  },
  locationButton: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "#FFFFFF",
  },
  locationButtonText: {
    fontSize: 11,
    color: "#0EA5E9",
    fontWeight: "600",
  },

  miniMapContainer: {
    width: "100%",
    height: 120,
    borderRadius: 18,
    overflow: "hidden",
    marginBottom: 8,
    marginTop: 4,
  },
  miniMap: {
    width: "100%",
    height: "100%",
  },

  imageScroll: { marginTop: 4, marginBottom: 4 },
  multiImage: {
    width: 180,
    height: 130,
    borderRadius: 18,
    marginRight: 10,
    backgroundColor: "#E5E7EB",
  },

  placeholderImage: {
    width: "100%",
    height: 130,
    backgroundColor: "#E5E7EB",
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 8,
  },
  placeholderText: {
    color: "#9CA3AF",
  },

  imageButton: {
    backgroundColor: "#FFFFFF",
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#0EA5E9",
    alignItems: "center",
    marginTop: 4,
  },
  imageButtonText: {
    color: "#0EA5E9",
    fontWeight: "500",
  },

  saveImageButton: {
    backgroundColor: "#0EA5E9",
    paddingVertical: 8,
    borderRadius: 999,
    alignItems: "center",
    marginTop: 6,
  },
  saveImageButtonText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  descriptionContainer: {
    backgroundColor: "#F3F4F6",
    padding: 10,
    borderRadius: 14,
    marginTop: 10,
  },
  descriptionText: {
    color: "#111827",
    lineHeight: 20,
    fontSize: 14,
  },
  placeholderDescription: {
    color: "#9CA3AF",
    fontStyle: "italic",
  },
  descriptionEditContainer: {
    marginTop: 10,
  },
  descriptionInput: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 14,
    padding: 10,
    backgroundColor: "#FFFFFF",
    color: "#111827",
    minHeight: 110,
    textAlignVertical: "top",
    fontSize: 14,
  },

  editRow: { flexDirection: "row", marginTop: 10 },
  editInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: "#FFFFFF",
    color: "#111827",
  },
  saveButton: {
    backgroundColor: "#0EA5E9",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    marginLeft: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  saveButtonText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  moodLabelSmall: {
    marginTop: 10,
    fontSize: 13,
    fontWeight: "600",
    color: "#111827",
  },
  moodOptionsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
    marginTop: 4,
  },
  moodButtonSmall: {
    flex: 1,
    paddingVertical: 6,
    marginHorizontal: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "#FFFFFF",
    alignItems: "center",
  },
  moodButtonSelected: {
    backgroundColor: "#0EA5E9",
    borderColor: "#0EA5E9",
  },
  moodEmoji: {
    fontSize: 18,
  },
  moodTextSmall: {
    fontSize: 12,
    color: "#4B5563",
  },
  moodTextSelected: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  cardMoodChip: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: "#EEF2FF",
    marginBottom: 8,
    marginTop: 4,
  },
  cardMoodEmoji: {
    fontSize: 18,
  },
  cardMoodChipText: {
    fontSize: 12,
    marginLeft: 6,
    color: "#4B5563",
    fontWeight: "600",
  },

  actionButtons: {
    flexDirection: "row",
    marginTop: 12,
    justifyContent: "space-between",
  },
  actionButton: {
    flex: 1,
    paddingVertical: 9,
    borderRadius: 12,
    alignItems: "center",
  },
  editButton: {
    backgroundColor: "#E0F2FE",
    marginRight: 8,
  },
  deleteButton: {
    backgroundColor: "#FEE2E2",
  },
  editButtonText: {
    color: "#0369A1",
    fontWeight: "600",
  },
  deleteButtonText: {
    color: "#B91C1C",
    fontWeight: "600",
  },

  // 🛠 FIXED IMAGE VIEWER OVERLAY
  viewerOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.97)",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 9999,
    elevation: 9999,
  },

  viewerCloseButton: {
    position: "absolute",
    top: 40,
    right: 20,
    padding: 12,
    zIndex: 10000,
    elevation: 10000,
  },

  viewerScroll: {
    width: "100%",
    height: "100%",
  },
  viewerPage: {
    width: SCREEN_WIDTH,
    justifyContent: "center",
    alignItems: "center",
  },
  viewerImage: {
    width: "90%",
    height: "70%",
    resizeMode: "contain",
  },

  dateOverlay: {
    position: "absolute",
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.3)",
    justifyContent: "center",
    alignItems: "center",
  },
  dateBox: {
    width: "85%",
    backgroundColor: "#FFFFFF",
    padding: 16,
    borderRadius: 18,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 12,
    elevation: 4,
  },
  dateTitle: {
    textAlign: "center",
    marginBottom: 10,
    fontSize: 16,
    fontWeight: "600",
    color: "#111827",
  },
  dateInput: {
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    color: "#111827",
    backgroundColor: "#F9FAFB",
  },
  dateButtonsRow: {
    flexDirection: "row",
    marginTop: 14,
    justifyContent: "space-between",
  },
  dateButton: {
    flex: 1,
    paddingVertical: 9,
    borderRadius: 12,
    alignItems: "center",
  },
  dateCancelButton: {
    backgroundColor: "#F3F4F6",
    marginRight: 6,
  },
  dateSaveButton: {
    backgroundColor: "#0EA5E9",
    marginLeft: 6,
  },
  dateCancelText: {
    color: "#4B5563",
    fontWeight: "600",
  },
  dateSaveText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },
});

import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  Alert,
} from "react-native";
import firebase from "../components/firebase";   
import { useNavigation } from "@react-navigation/native";

export default function Signup() {
  const navigation = useNavigation();

  const [isLoginFormVisible, setIsLoginFormVisible] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const toggleForm = () => {
    setIsLoginFormVisible(!isLoginFormVisible);
    setEmailError("");
    setPasswordError("");
    setEmail("");
    setPassword("");
    setName("");
  };

  const handleAuthentication = async () => {
    if (!email.includes("@")) {
      setEmailError("Invalid email format");
      return;
    } else {
      setEmailError("");
    }

    if (password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      return;
    } else {
      setPasswordError("");
    }

    try {
      if (isLoginFormVisible) {
        // LOGIN
        await firebase.auth().signInWithEmailAndPassword(email, password);
        Alert.alert("Login Successful", `Welcome back, ${email}!`);
        navigation.navigate("Tabs"); // ⭐ GOTO Bottom Tabs
      } else {
        // SIGNUP
        await firebase.auth().createUserWithEmailAndPassword(email, password);
        Alert.alert("Sign Up Successful", `Welcome, ${name}!`);
        navigation.navigate("Tabs"); // ⭐ GOTO Bottom Tabs
      }
    } catch (error) {
      Alert.alert("Authentication Error", error.message);
    }
  };

  return (
    <ImageBackground
      source={require("../assets/trip.png")} // FIXED PATH
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <View
          style={[
            styles.formContainer,
            !isLoginFormVisible && styles.slideUp,
          ]}
        >
          <Text style={styles.formTitle}>
            Sign {isLoginFormVisible ? "In" : "Up"}
          </Text>

          <View style={styles.formHolder}>
            {!isLoginFormVisible && (
              <TextInput
                style={styles.input}
                placeholder="Name"
                value={name}
                onChangeText={setName}
              />
            )}

            <TextInput
              style={styles.input}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
            />
            {emailError !== "" && (
              <Text style={styles.errorText}>{emailError}</Text>
            )}

            <TextInput
              style={styles.input}
              placeholder="Password"
              secureTextEntry={true}
              value={password}
              onChangeText={setPassword}
            />
            {passwordError !== "" && (
              <Text style={styles.errorText}>{passwordError}</Text>
            )}

            <TouchableOpacity
              style={styles.submitBtn}
              onPress={handleAuthentication}
            >
              <Text style={styles.btnText}>
                {isLoginFormVisible ? "Login" : "Sign Up"}
              </Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={toggleForm}>
            <Text style={styles.formToggle}>
              {isLoginFormVisible
                ? "Create an account"
                : "Already have an account?"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  backgroundImage: {
    flex: 1,
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  formContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.2)",
    borderRadius: 15,
    height: 600,
    width: 350,
    overflow: "hidden",
  },
  slideUp: {
    transform: [{ translateY: 0 }],
  },
  formTitle: {
    color: "#fff",
    fontSize: 24,
    textAlign: "center",
    marginTop: 20,
  },
  formHolder: {
    borderRadius: 15,
    backgroundColor: "#fff",
    marginTop: 20,
    padding: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 5,
    height: 40,
    paddingLeft: 10,
    marginBottom: 15,
  },
  submitBtn: {
    backgroundColor: "rgba(0,0,0,0.8)",
    borderRadius: 15,
    paddingVertical: 15,
    alignItems: "center",
    marginTop: 15,
  },
  btnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  formToggle: {
    color: "#fff",
    textAlign: "center",
    marginTop: 20,
  },
  errorText: {
    color: "red",
    marginBottom: 10,
  },
});
